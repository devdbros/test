<?php
$servername = "localhost";
$username = "php7_study";
$password = "php7study";
$database = "php7_study";

try {
    $db = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
	$db->exec("SET CHARACTER SET utf8");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//    echo "Connected successfully";
}catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
    exit();
}


// dishes.txt 파일을 쓰기 모드로 열기
$file = fopen('dishes.txt', 'wb');

$stmt = $db->query("SELECT seq, dish_name, price, is_spicy FROM menu");
while( $row = $stmt->fetch() ){
    // 각 줄을 파일에 쓰고 마지막에 개행문자 추가
    print "$row[1] 추가되었습니다.<br>";
    fwrite($file, "$row[1]의 가격은 $row[2]\n");
}

if(! fclose($file)){
    print "dishes.txt 파일을 닫을 수 없습니다 : $php_errormsg";
}
