<?php
$servername = "localhost";
$username = "php7_study";
$password = "php7study";
$database = "php7_study";

try {
    $db = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
	$db->exec("SET CHARACTER SET utf8");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//    echo "Connected successfully";
}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
    exit();
}
//header('Content-Encoding: UTF-8');
header('Content-Type: text/csv');//charset=UTF-8');
header('Content-Disposition: attachment; filename="menu.csv"');

echo "\xEF\xBB\xBF"; // UTF-8 BOM
// 출력 스트림을 향해 열기
$file = fopen('php://output', 'wb');


$dishes = $db->query("SELECT seq, dish_name, price, is_spicy FROM menu");
while( $row = $dishes->fetch(PDO::FETCH_NUM) ){
    // 각 줄을 파일에 쓰고 마지막에 개행문자 추가
//    print "$row[1] 추가되었습니다.<br>";
//    fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));
//    $row = array_map("utf8_decode", $row);
    fputcsv($file, $row);
}








?>
