<?php
print "</><p>";
// 파일명에 들어갈 변수를 안전하게 조치하기
//$filename = "../dishes.txt";
$filename = str_replace('/', '', $_GET['file']);
$filename = str_replace('..', '', $filename);

if(is_readable($filename)){
    print "파일명 : ".htmlentities($filename)."<br>";
    print file_get_contents($filename);
}else{
    print "파일을 찾을 수 없습니다.($filename)";
}

echo "<p>";

// realpath()로 파일명 처리하기
$file = $_GET['file'];      //"dishes1.txt";
$real_file = realpath("files/".$file);      //.$_GET['file']);

$real_file = realpath("files/$_GET[file]");      //.$_GET['file']);
//$real_file 이 해당 폴더에 존재하는지 확인
//print "realpath : $real_file ".dirname(__FILE__)."<br>";
if(dirname(__FILE__).'\\files\\'.$file == $real_file && is_readable($real_file)){
//if(('/usr/local/data/' == substr($filename, 0, 16)) && is_readable($filename)){
    print "파일명 : $file<br>";
    print "실제파일경로 : $real_file<br>";
    print file_get_contents($real_file);
}else{
    print "$file 파일이 존재하지 않습니다.<br>".dirname(__FILE__)."\\files\\".$file."<br>$real_file";
}
