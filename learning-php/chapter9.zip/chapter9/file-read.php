<?php
$pageContent = file_get_contents('page-template.html');

$pageContent = str_replace('{page_title}', '페이지 제목', $pageContent);

$pageContent = str_replace('{bg_color}', '#a0c3f9', $pageContent);

$pageContent = str_replace('{user_name}', '관리자', $pageContent);
print $pageContent;

echo '<p>';
