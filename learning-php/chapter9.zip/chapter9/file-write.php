<?php
$pageContent = file_get_contents('page-template.html');

$pageContent = str_replace('{page_title}', 'File Write', $pageContent);

$pageContent = str_replace('{bg_color}', '#f5f7a9', $pageContent);

$pageContent = str_replace('{user_name}', '관리자', $pageContent);
$pageContent = str_replace(', ', ',<br>', $pageContent);
print $pageContent;

echo '<p>';


//파일에 쓰기
$pageContent .= "하단에 내용을 추가됩니다.";

file_put_contents('page.html', "\xEF\xBB\xBF".$pageContent);
//file_put_contents('page.html', "\xEF\xBB\xBF".$pageContent);
