<?php
// fopen(), fclose()의 오류 확인하기
$servername = "localhost";
$username = "php7_study";
$password = "php7study";
$database = "php7_study";

try {
    $db = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
	$db->exec("SET CHARACTER SET utf8");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//    echo "Connected successfully";
}catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// dishes.txt 파일을 쓰기 모드로 열기
$filename = "dishes.txt";
$file = fopen($filename, 'wb');
if(!$file){
    print "<b>$filename 파일을 불러올 수 없습니다.</b><p>";
}else{
    $stmt = $db->query("SELECT seq, dish_name, price, is_spicy FROM menu");
    while( $row = $stmt->fetch() ){
        // 각 줄을 파일에 쓰고 마지막에 개행문자 추가
        print "$row[1] 추가되었습니다.<br>";
        fwrite($file, "$row[1]의 가격은 $row[2]\n");
    }

    if(! fclose($file)){
        print "<b>$filename 파일을 닫을 수 없습니다 : $php_errormsg</b><p>";
    }
}

// file_get_contents()의 오류 확인하기
$filename = "page-template-copy.html";
$page = file_get_contents($filename);
// 삼중등호를 이용한 조건 표현식
if($page === false){
    print "<p><b>$filename 파일을 불러올 수 없습니다.</b><p>";
}else{
    print "<p><b>$filename 파일을 불러왔습니다.</b><p>";
}

// fopen(), fgets(), fclose()의 오류 확인하기
$filename = 'people.txt';
$file = fopen($filename, 'rb');
if(! $file ){
    print $filename." 파일을 열 수 없습니다 : $php_errormsg";
}else{
	print '<table>';
    while(! feof($file)){
        $line = fgets($file);
        // 삼중등호를 이용한 조건 표현식
        if($line !== false){
            $line = trim($line);
            $info = explode('|', $line);
            print "<tr><td>$info[0]</td><td>$info[1]</td><td>$info[2]</td></tr>";
        }
    }
	print '</table>';
    if(! fclose($file)){
        print $filename." 파일을 닫을 수 없습니다 : $php_errormsg";
    }
}

// file_put_contents()의 오류 확인하기
$filename = "page-template-copy.html";
$pageContent = file_get_contents($filename);

$pageContent = str_replace('{page_title}', 'File Write', $pageContent);

$pageContent = str_replace('{bg_color}', '#a9f7a9', $pageContent);

$pageContent = str_replace('{user_name}', 'User', $pageContent);
$pageContent = str_replace(', ', ',<br>', $pageContent);
print $pageContent;

echo '<p>';


//파일에 쓰기
$pageContent .= "하단에 내용을 추가됩니다.";

$result = file_put_contents('page-content.html', "\xEF\xBB\xBF".$pageContent);
if($result === false || ($result == -1)){
    print $filename." 파일을 저장할 수 없습니다.";
}else{
    print $filename." 파일을 저장했습니다.";
}
?>
