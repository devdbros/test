<?php
$servername = "localhost";
$username = "php7_study";
$password = "php7study";
$database = "php7_study";

try {
    $db = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
	$db->exec("SET CHARACTER SET utf8");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//    echo "Connected successfully";
}catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
    exit();
}


// menu.csv 파일을 읽기 모드로 열기
$file = fopen('menu.csv', 'rb');

$stmt = $db->prepare('INSERT INTO menu (dish_name, price, is_spicy) VALUES (?, ?, ?)');

while(! feof($file) && ($info = fgetcsv($file) ) ){
    // 각 줄을 파일에 쓰고 마지막에 개행문자 추가
    $stmt -> execute($info);
    print "<br>$info[0] 추가되었습니다.";
    //fwrite($file, "$row[0]의 총 참여자 수는 $row[3]\n");
}
if(! fclose($file)){
    print "menu.csv 파일을 닫을 수 없습니다 : $php_errormsg";
}







?>
