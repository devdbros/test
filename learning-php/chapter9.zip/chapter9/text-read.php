<?php

foreach(file('event.txt') as $line){
	$line = trim($line);           // 문자열 끝의 개행문자를 제거한다.
	$info = explode("|", $line);   // | 구분자로 문자열을 분리

	print $info[0].' : '.$info[3]."<br>";

//	foreach($info as $thisline){
//		print '-'.$thisline;
//	}
}
/*
이벤트명 : 참여자수
스티커 이벤트 : 1000명
이미지합성 : 제한없음
*/

echo '<p>';
$file = fopen('event.txt', 'rb');       // event.txt 를 읽기전용으로 열기
while ((! feof($file)) && ($line = fgets($file))){
	$line = trim($line);
	$info = explode("|", $line);

	print $info[0].' : '.$info[1]."<br>";
}
fclose($file);


/*
$file = fopen('people.txt', 'rb');
while( (!feof($file)) && ($line = fgets($file)) ){
    $line = trim($line);
    $info = explode('|', $line);
    print "<li>$info[0] ($info[1])</li>\n";
}
fclose($file);
*/
