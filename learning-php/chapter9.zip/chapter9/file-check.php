<?php


//파일 존재 여부 확인
if(file_exists('event.txt')){
    echo "event.txt 파일이 존재합니다.";
}else{
    echo "event.txt 파일이 없습니다.";
}

// 읽기 권한 테스트
$template_file = 'page-template.html';
if(is_readable($template_file)){
    $template = file_get_contents($template_file);
    echo $template;
}else{
    echo "$template_file 파일을 읽을 수 없습니다.";
}

// 쓰기 권한 테스트
$log_file = 'file.log';
if(is_writable($log_file)){
    $_SESSION['username'] = 'USER11';
    $file = fopen($log_file, 'ab');
    fwrite($file, $_SESSION['username'].' at '.strftime('%c')."\n");
    fclose($file);
}else{
    echo "file.log 파일을 쓸 수 없습니다.";
}
 ?>
